import javax.swing.*;
import java.awt.*;
import java.util.function.BiConsumer;
import java.util.ArrayList;

public class PantallaPrincipal {
    private static ArrayList<String> materias = new ArrayList<>();
    private static ArrayList<String> horarios = new ArrayList<>();

    private static ArrayList<Double> notas = new ArrayList<>();
    private static ArrayList<Integer> creditos = new ArrayList<>();

    private static ArrayList<String> actividades = new ArrayList<>();
    private static ArrayList<Integer> horas = new ArrayList<>();
    private static int horasLibresTotales = 0;

    public static void mostrarPantallaPrincipal(String username) {
        JFrame mainFrame = new JFrame("Pantalla Principal");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        mainFrame.setSize(screenSize.width - 100, screenSize.height - 100);
        mainFrame.setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Encabezado
        JPanel topPanel = new JPanel(new BorderLayout(10, 10));
        topPanel.setBackground(new Color(240, 240, 240));

        // Logo
        ImageIcon logoIcon = new ImageIcon("logo.png");
        if (logoIcon.getIconWidth() > 0) {
            int scaledWidth = 200;
            int scaledHeight = (int) ((double) scaledWidth / logoIcon.getIconWidth() * logoIcon.getIconHeight());
            Image scaledImage = logoIcon.getImage().getScaledInstance(scaledWidth, scaledHeight, Image.SCALE_SMOOTH);
            JLabel logoLabel = new JLabel(new ImageIcon(scaledImage));
            topPanel.add(logoLabel, BorderLayout.WEST);
        }

        JLabel userNameLabel = new JLabel("Bienvenido, " + username);
        userNameLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        userNameLabel.setHorizontalAlignment(SwingConstants.CENTER);
        topPanel.add(userNameLabel, BorderLayout.CENTER);

        mainPanel.add(topPanel, BorderLayout.NORTH);

        // Navegación
        JPanel navPanel = new JPanel();
        navPanel.setLayout(new BoxLayout(navPanel, BoxLayout.Y_AXIS));
        navPanel.setBackground(new Color(250, 250, 250));
        navPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        Font buttonFont = new Font("SansSerif", Font.PLAIN, 16);
        JButton btnAgregarMateria = crearBoton("Agregar Materia", buttonFont, navPanel);
        JButton btnVerHorario = crearBoton("Ver Horario", buttonFont, navPanel);
        JButton btnCalcularPGA = crearBoton("Calcular PGA", buttonFont, navPanel);
        JButton btnAgregarHorasLibres = crearBoton("Agregar Horas Libres", buttonFont, navPanel);
        JButton btnVerHorasLibres = crearBoton("Ver Horas Libres", buttonFont, navPanel);
        JButton btnCerrarSesion = crearBoton("Cerrar Sesión", buttonFont, navPanel);

        mainPanel.add(navPanel, BorderLayout.WEST);

        // Contenido dinámico
        JPanel contentPanel = new JPanel(new CardLayout());
        contentPanel.setBackground(Color.WHITE);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        // Función para agregar materias al calendario
        btnAgregarMateria.addActionListener(e -> {
            JPanel agregarMateriaPanel = new JPanel(new BorderLayout(10, 10));

            // Panel del formulario
            JPanel formularioPanel = new JPanel(new GridLayout(4, 2, 10, 10));
            formularioPanel.setBorder(BorderFactory.createTitledBorder("Información de la Materia"));

            JTextField materiaField = new JTextField();
            String[] dias = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes"};
            JComboBox<String> diaCombo = new JComboBox<>(dias);
            JTextField horaInicioField = new JTextField("Hora Inicio (ej: 08:00)");
            JTextField horaFinField = new JTextField("Hora Fin (ej: 10:00)");

            formularioPanel.add(new JLabel("Materia:"));
            formularioPanel.add(materiaField);
            formularioPanel.add(new JLabel("Día:"));
            formularioPanel.add(diaCombo);
            formularioPanel.add(new JLabel("Hora Inicio:"));
            formularioPanel.add(horaInicioField);
            formularioPanel.add(new JLabel("Hora Fin:"));
            formularioPanel.add(horaFinField);

            agregarMateriaPanel.add(formularioPanel, BorderLayout.CENTER);

            // Botón para guardar
            JButton guardarButton = new JButton("Guardar Materia");
            guardarButton.addActionListener(ev -> {
                try {
                    String materia = materiaField.getText();
                    String dia = (String) diaCombo.getSelectedItem();
                    String horaInicio = horaInicioField.getText();
                    String horaFin = horaFinField.getText();

                    if (materia.isEmpty() || horaInicio.isEmpty() || horaFin.isEmpty()) {
                        JOptionPane.showMessageDialog(mainFrame, "Por favor, completa todos los campos.");
                        return;
                    }

                    String horario = dia + " de " + horaInicio + " a " + horaFin;
                    materias.add(materia);
                    horarios.add(horario);

                    JOptionPane.showMessageDialog(mainFrame, "Materia agregada: " + materia + " (" + horario + ")");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(mainFrame, "Error al guardar la materia.");
                }
            });

            agregarMateriaPanel.add(guardarButton, BorderLayout.SOUTH);
            mostrarContenido(contentPanel, agregarMateriaPanel);
        });

        // Función para ver horario
        btnVerHorario.addActionListener(e -> {
            JPanel horarioPanel = new JPanel(new BorderLayout(10, 10));

            if (materias.isEmpty()) {
                horarioPanel.add(new JLabel("No hay materias registradas.", SwingConstants.CENTER), BorderLayout.CENTER);
            } else {
                String[] columnNames = {"Materia", "Horario"};
                Object[][] data = new Object[materias.size()][2];
                for (int i = 0; i < materias.size(); i++) {
                    data[i][0] = materias.get(i);
                    data[i][1] = horarios.get(i);
                }
                JTable table = new JTable(data, columnNames);
                JScrollPane scrollPane = new JScrollPane(table);
                horarioPanel.add(scrollPane, BorderLayout.CENTER);
            }

            mostrarContenido(contentPanel, horarioPanel);
        });

        // Función para calcular PGA
        btnCalcularPGA.addActionListener(e -> {
            JPanel pgaPanel = new JPanel(new GridLayout(0, 2, 10, 10));
            JTextField creditosField = new JTextField();
            JTextField notaField = new JTextField();

            pgaPanel.add(new JLabel("Créditos:"));
            pgaPanel.add(creditosField);
            pgaPanel.add(new JLabel("Nota:"));
            pgaPanel.add(notaField);

            JButton agregarButton = new JButton("Agregar Materia");
            agregarButton.addActionListener(ev -> {
                try {
                    int creditosValue = Integer.parseInt(creditosField.getText());
                    double notaValue = Double.parseDouble(notaField.getText());

                    creditos.add(creditosValue);
                    notas.add(notaValue);

                    JOptionPane.showMessageDialog(mainFrame, "Materia agregada para el cálculo del PGA.");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(mainFrame, "Por favor, ingresa valores válidos.");
                }
            });

            JButton calcularButton = new JButton("Calcular PGA");
            calcularButton.addActionListener(ev -> {
                if (creditos.isEmpty() || notas.isEmpty()) {
                    JOptionPane.showMessageDialog(mainFrame, "No hay materias suficientes para calcular el PGA.");
                    return;
                }

                double sumaNotas = 0;
                int sumaCreditos = 0;
                for (int i = 0; i < notas.size(); i++) {
                    sumaNotas += notas.get(i) * creditos.get(i);
                    sumaCreditos += creditos.get(i);
                }

                double pga = Math.floor((sumaNotas / sumaCreditos) * 100) / 100;
                JOptionPane.showMessageDialog(mainFrame, "Tu PGA es: " + pga);
            });

            pgaPanel.add(agregarButton);
            pgaPanel.add(calcularButton);

            mostrarContenido(contentPanel, pgaPanel);
        });

        // Función para agregar horas libres
        btnAgregarHorasLibres.addActionListener(e -> {
            JPanel agregarHorasPanel = crearPanelFormulario("Actividad", "Horas", "Guardar Actividad", (actividad, horasStr) -> {
                try {
                    int horasInt = Integer.parseInt(horasStr);
                    if (horasInt > 0) {
                        actividades.add(actividad);
                        horas.add(horasInt);
                        horasLibresTotales += horasInt;
                        JOptionPane.showMessageDialog(mainFrame,
                                "Actividad '" + actividad + "' guardada con " + horasInt + " horas.");
                    } else {
                        JOptionPane.showMessageDialog(mainFrame, "Por favor, ingresa un valor positivo.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(mainFrame, "Por favor, ingresa un número válido.");
                }
            });
            mostrarContenido(contentPanel, agregarHorasPanel);
        });

        // Función para ver horas libres
        btnVerHorasLibres.addActionListener(e -> {
            JPanel verHorasPanel = new JPanel(new BorderLayout(10, 10));
            if (actividades.isEmpty()) {
                verHorasPanel.add(new JLabel("No se han registrado actividades libres.", SwingConstants.CENTER), BorderLayout.CENTER);
            } else {
                String[] columnNames = {"Actividad", "Horas"};
                Object[][] data = new Object[actividades.size()][2];
                for (int i = 0; i < actividades.size(); i++) {
                    data[i][0] = actividades.get(i);
                    data[i][1] = horas.get(i);
                }
                JTable table = new JTable(data, columnNames);
                JScrollPane scrollPane = new JScrollPane(table);
                verHorasPanel.add(scrollPane, BorderLayout.CENTER);

                JLabel totalLabel = new JLabel("Horas libres totales: " + horasLibresTotales, SwingConstants.CENTER);
                totalLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
                verHorasPanel.add(totalLabel, BorderLayout.SOUTH);
            }
            mostrarContenido(contentPanel, verHorasPanel);
        });

        btnCerrarSesion.addActionListener(e -> mainFrame.dispose());

        mainFrame.add(mainPanel);
        mainFrame.setVisible(true);
    }

    private static JPanel crearPanelFormulario(String label1, String label2, String buttonText,
                                               BiConsumer<String, String> onSave) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JPanel formPanel = new JPanel(new GridLayout(2, 2, 10, 10));

        JTextField field1 = new JTextField();
        JTextField field2 = new JTextField();

        formPanel.add(new JLabel(label1 + ":"));
        formPanel.add(field1);
        formPanel.add(new JLabel(label2 + ":"));
        formPanel.add(field2);

        JButton saveButton = new JButton(buttonText);
        saveButton.addActionListener(e -> onSave.accept(field1.getText(), field2.getText()));

        panel.add(formPanel, BorderLayout.CENTER);
        panel.add(saveButton, BorderLayout.SOUTH);

        return panel;
    }

    private static JButton crearBoton(String texto, Font font, JPanel panel) {
        JButton boton = new JButton(texto);
        boton.setFont(font);
        boton.setPreferredSize(new Dimension(200, 40));
        boton.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(boton);
        panel.add(Box.createVerticalStrut(10));
        return boton;
    }

    private static void mostrarContenido(JPanel contentPanel, JPanel newContent) {
        contentPanel.removeAll();
        contentPanel.add(newContent);
        contentPanel.revalidate();
        contentPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> mostrarPantallaPrincipal("Juan Pérez"));
    }
}
