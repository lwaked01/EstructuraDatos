import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class SistemaGestionEstudiantil {
    // Mapa para almacenar usuarios y contraseñas
    private static HashMap<String, String> users = new HashMap<>();

    public static void main(String[] args) {
        // Ejecuta el código en el hilo de eventos de Swing
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // Crear y mostrar la ventana
                crearVentana();
            }
        });
    }

    public static void crearVentana() {
        // Crear ventana (JFrame)
        JFrame frame = new JFrame("Sistema de Gestión Estudiantil");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setUndecorated(false);

        CardLayout cardLayout = new CardLayout();
        JPanel panelContenedor = new JPanel(cardLayout);

        JPanel panelLogin = crearPanelLogin(frame, cardLayout, panelContenedor);
        JPanel panelRegistro = crearPanelRegistro(frame, cardLayout, panelContenedor);

        panelContenedor.add(panelLogin, "Login");
        panelContenedor.add(panelRegistro, "Registro");

        frame.add(panelContenedor);
        frame.setVisible(true);
    }

    public static JPanel crearPanelLogin(JFrame frame, CardLayout cardLayout, JPanel panelContenedor) {
        JPanel panelLogin = new JPanel();
        panelLogin.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        ImageIcon logoIcon = new ImageIcon("logo.png");
        JLabel logoLabel = new JLabel(logoIcon);
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panelLogin.add(logoLabel, gbc);

        JLabel usernameLabel = new JLabel("Usuario:");
        JTextField usernameField = new JTextField(20);
        JLabel passwordLabel = new JLabel("Contraseña:");
        JPasswordField passwordField = new JPasswordField(20);

        JButton loginButton = new JButton("Iniciar Sesión");
        JButton createAccountButton = new JButton("Crear Cuenta");

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelLogin.add(usernameLabel, gbc);

        gbc.gridx = 1;
        panelLogin.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panelLogin.add(passwordLabel, gbc);

        gbc.gridx = 1;
        panelLogin.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panelLogin.add(loginButton, gbc);

        gbc.gridx = 1;
        panelLogin.add(createAccountButton, gbc);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (users.containsKey(username)) {
                    String storedPassword = users.get(username);
                    if (storedPassword.equals(password)) {
                        JOptionPane.showMessageDialog(frame, "Inicio de sesión exitoso.");
                        frame.dispose();

                        PantallaPrincipal.mostrarPantallaPrincipal(username);
                    } else {
                        JOptionPane.showMessageDialog(frame, "Contraseña incorrecta.");
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Usuario no encontrado.");
                }
            }
        });

        createAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(panelContenedor, "Registro");
            }
        });

        return panelLogin;
    }

    public static JPanel crearPanelRegistro(JFrame frame, CardLayout cardLayout, JPanel panelContenedor) {
        JPanel panelRegistro = new JPanel();
        panelRegistro.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        ImageIcon logoIcon = new ImageIcon("logo.png");
        JLabel logoLabel = new JLabel(logoIcon);
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panelRegistro.add(logoLabel, gbc);

        JLabel usernameLabel = new JLabel("Nuevo Usuario:");
        JTextField usernameField = new JTextField(20);
        JLabel passwordLabel = new JLabel("Nueva Contraseña:");
        JPasswordField passwordField = new JPasswordField(20);
        JLabel confirmPasswordLabel = new JLabel("Confirmar Contraseña:");
        JPasswordField confirmPasswordField = new JPasswordField(20);

        JButton registerButton = new JButton("Registrar");
        JButton backButton = new JButton("Volver al Login");

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelRegistro.add(usernameLabel, gbc);

        gbc.gridx = 1;
        panelRegistro.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panelRegistro.add(passwordLabel, gbc);

        gbc.gridx = 1;
        panelRegistro.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panelRegistro.add(confirmPasswordLabel, gbc);

        gbc.gridx = 1;
        panelRegistro.add(confirmPasswordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panelRegistro.add(registerButton, gbc);

        gbc.gridx = 1;
        panelRegistro.add(backButton, gbc);

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String confirmPassword = new String(confirmPasswordField.getPassword());

                if (password.equals(confirmPassword)) {
                    if (users.containsKey(username)) {
                        JOptionPane.showMessageDialog(frame, "El nombre de usuario ya está en uso.");
                    } else {
                        users.put(username, password);
                        JOptionPane.showMessageDialog(frame, "Cuenta creada exitosamente.");
                        usernameField.setText("");
                        passwordField.setText("");
                        confirmPasswordField.setText("");
                        cardLayout.show(panelContenedor, "Login");
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Las contraseñas no coinciden.");
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(panelContenedor, "Login");
            }
        });

        return panelRegistro;
    }
}
